<?php

class PagginationModel extends CI_Model {



    public function __construct() {

        parent::__construct();

		$this->sample_tbl = 'sample';

		
    }
	
	function getData($limit, $offset) {
    	$this->db->select();
    	$this->db->from($this->sample_tbl); 
		$this->db->limit($limit, $offset);
    	$query = $this->db->get();
    	//echo $this->db->last_query();die;
    	return $query->result_array();
    }
	function getData1() {
    	$this->db->select();
    	$this->db->from($this->sample_tbl); 
    	$query = $this->db->get();
    	//echo $this->db->last_query();die;
    	return $query->result_array();
    }
	

}



?>