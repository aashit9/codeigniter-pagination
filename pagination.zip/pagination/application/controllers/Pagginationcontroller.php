<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class PagginationController extends CI_Controller{

	public function __construct() {
		parent::__construct();

		date_default_timezone_set("Asia/Kolkata");
		session_regenerate_id();
		$this->load->model('PagginationModel');
	}
	
	function paggination() {
		$data['getData1'] = $this->PagginationModel->getData1();
		
		$this->load->library("pagination");
		$this->load->helper("url");
		
		$config['total_rows'] = count($data['getData1']);
		$config['base_url'] = base_url();
		$config['full_tag_open'] = '<ul class="pagination" style="float:right">';
		$config['cur_tag_open'] = '<li class="active"><a href="">';
		$config['cur_tag_close'] = $config['first_tag_close'] = $config['num_tag_close'] = $config['prev_tag_close'] = '</a></li>';
		$config['num_tag_open'] = $config['first_tag_open'] = '<li>';
		$config['prev_tag_open'] = '<li>';
		$config['next_tag_open'] = '<li>';
		$config['next_tag_close'] = '</li>';
		$config['full_tag_close'] = '<ul/>';
		$data['page'] = $offset = ($this->input->get('page') != '' ? $this->input->get('page'): 1);
		$config['per_page']= 10;
		$offset = ($offset-1)*$config['per_page'];
		$data['sr_no'] = $offset+1;
		$config['uri_segment'] = 1;
		$config['use_page_numbers'] = TRUE;
		$config['page_query_string'] = TRUE;
		$config['query_string_segment'] = 'page';
		
		$choice = $config['total_rows'] / $config['per_page'];
		
		$config['num_links'] = 10;//round($choice);
		
		
		$query_string = $_GET;
		//var_dump($query_string);
		if (isset($query_string['page']))
		{
			unset($query_string['page']);
		}
		
		$data['query_string'] = $query_string;
		// build first url link
		$config['first_url'] = $config['base_url']. '/?' . http_build_query($query_string);
		//var_dump($config);
		// if $get contains items then build these back onto the url
		if (count($query_string) > 0) $config['suffix'] = '&' . http_build_query($query_string);		
		$this->pagination->initialize($config);
		$data['paginglinks'] = $this->pagination->create_links();
		
		$data['getData'] = $this->PagginationModel->getData($config["per_page"], $offset);
		
		$this->load->view('pagination_view',$data);
	}
	
	
}
